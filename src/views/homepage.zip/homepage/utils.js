import inputConfig from "./config/inputConfig";

export default {

    /**
     * 初始化所有输入项的值 null
     */
    initInputsValues() {
        const inputValues = {};
        inputConfig.forEach(item => inputValues[item.name] = null);
        return inputValues
    },

    /**
     * 聚焦下一个输入框
     * @param currentName inputConfig中某一项的name属性
     * @param init 是否是初始化，需要聚焦第一个输入项
     */
    focusNext(currentName, init) {
        const index = inputConfig.findIndex(item => item.name === currentName);
        if (index >= 0 && inputConfig[index + 1]) {
            // 非第一个的情况下，如果当前编辑的是select或date，需要先将其进行隐藏
            if (!init) {
                // 当前输入项
                const currentItem = inputConfig[index];
                // 如果当前聚焦的是一个select，需要通过点击来隐藏当前的下拉选项
                if (currentItem.type === 'select') {
                    const currentBoxEl = document.getElementById(currentItem.name);
                    const inputEl = currentBoxEl ? currentBoxEl.querySelector('.el-input__inner') : null;
                    !inputEl.value && inputEl.click();
                }
                // 当前聚焦是个日期，手动隐藏下拉框
                if (currentItem.type === 'date') {
                    const wrap = document.querySelector(`.date-${currentName}`);
                    if (wrap) wrap.style.display = 'none'
                }
            }
            // 查找下一个输入项input并聚焦
            const nextItem = init ? inputConfig[index] : inputConfig[index + 1];
            const boxEl = document.getElementById(nextItem.name);
            const inputEl = boxEl ? boxEl.querySelector('.el-input__inner') : null;
            // select需要通过触发点击来展开下拉选项
            if (nextItem.type === 'select') inputEl && inputEl.click();
            else inputEl && inputEl.focus();
        }
    },

    /**
     * 整理组合所有输入项的值
     * @param data
     * @returns {*}
     */
    setInputValues(data) {
        let inputValues = this.initInputsValues();
        // 遍历data.bazaDO
        // Object.keys(data.bazaDO).forEach(key => {
        //     if (key === 'bazad7' || key === 'bazad8') { // 特殊处理: 颅脑损伤患者昏迷时间 入院前后
        //         const days = '', hours = '', minutes = '';
        //         inputValues[`bazaDO.${key}-days`] = days;
        //         inputValues[`bazaDO.${key}-hours`] = hours;
        //         inputValues[`bazaDO.${key}-minutes`] = minutes;
        //     } else {
        //         inputValues[`bazaDO.${key}`] = data.bazaDO[key]
        //     }
        // });
        // // 遍历data.baf6DO(各类费用)
        // Object.keys(data.baf6DO).forEach(key => {
        //     inputValues[`baf6DO.${key}`] = data.baf6DO[key]
        // });
        return inputValues
    },

    /**
     * 整理组合诊断表格的数据
     * @param data
     * @returns {*}
     */
    setDiagnoseTable(data) {
        return {
            diagnoseData: [
                {type: 'main', code1: 1, name1: 11, code2: 4, name2: 44},
                {type: 'qita', code1: 2, name1: 22, code2: 5, name2: 55},
                {type: 'qita', code1: 3, name1: 33, code2: 6, name2: 66},
                {}
            ], // 诊断表格数据
            currentInput: {rowIndex: 0, colIndex: 0}, // 当前在录入诊断表格中哪行数据
            visible: false,
            isPingYin: true, // 是否拼音
            form: {code: undefined, name: undefined},
            currentRowKey: undefined,
            codeData: []
        }
    },

    /**
     * 整理组合手术表格的数据
     * @param data
     * @returns {*}
     */
    setOperationTable(data) {
        if (data.bazaDO && data.bazaDO.baza53 == "1") {
            const data = (data.baf4DO || []).map(item => ({
                ...item,
                baf411: item.baf411.slice(0, 10), // 手术及操作日期
            }));
            return {data}
        }
        return {
            data: [{}, {}]
        }
    }
}

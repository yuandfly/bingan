// 所有输入项配置

const a = {
    label: '',
    name: ''
};

import options from "./optionConfig";
export default  [

    // 第一段（0 - 46）

    {label: '医疗付费方式', name: 'bazaDO.bazae1', type: 'select', options: options.payType, span: 6},
    {label: '健康卡号', name: 'bazaDO.baza01', type: 'text', span: 6},
    {label: '住院次数', name: '住院次数', type: 'text', after: '次', span: 6},
    {label: '病案号', name: 'bazaDO.baza00', type: 'text', span: 6},

    {label: '姓名', name: 'bazaDO.baza02', type: 'text', span: 6},
    {label: '性别', name: 'bazaDO.baza03', type: 'select', options: options.sex, span: 3},
    {label: '出生日期', name: 'bazaDO.baza04', type: 'date', span: 6},
    {label: '年龄', name: 'bazaDO.baza06', type: 'text', after: '岁', span: 3},
    {label: '国籍', name: 'bazaDO.nationality', type: 'text', span: 6},

    {label: '(年龄不足1周岁的)年龄', name: 'bazaDO.baza06', type: 'number', max: 1, min: 0, showCondition: 'showNewBaby', span: 8},
    {label: '新生儿出生体重', name: 'bazaDO.bazaf3', type: 'number', max: 10000, min: 1, showCondition: 'showNewBaby', after: '克', span: 8},
    {label: '新生儿入院体重', name: 'bazaDO.bazaf4', type: 'number', max: 10000, min: 1, showCondition: 'showNewBaby', after: '克', span: 8},

    // TODO 缺少籍贯一栏

    {label: '身份证号', name: 'bazaDO.baza05', type: 'text', span: 10},
    {label: '职业', name: 'bazaDO.profession', type: 'text', span: 8},
    {label: '婚姻', name: 'bazaDO.baza07', type: 'select', options: options.marry, span: 6},

    {label: '现住址', name: 'bazaDO.bazaf7', type: 'text', span: 10},
    {label: '电话', name: 'bazaDO.bazaa5', type: 'text', span: 8},
    {label: '邮编', name: 'bazaDO.bazaa6', type: 'text', span: 6},

    {label: '户口地址', name: '户口地址', type: 'text', span: 18},
    {label: '邮编', name: '户口地址邮编', type: 'text', span: 6},

    {label: '工作单位及地址', name: 'bazaDO.bazaa3', type: 'text', span: 10},
    {label: '单位电话', name: 'bazaDO.baza11', type: 'text', span: 8},
    {label: '邮编', name: 'bazaDO.bazaa4', type: 'text', span: 6},

    {label: '联系人姓名', name: 'bazaDO.baza15', type: 'text', span: 6},
    {label: '关系', name: 'bazaDO.baza16', type: 'select', options: options.relation, span: 4},
    {label: '地址', name: 'bazaDO.baza17', type: 'text', span: 8},
    {label: '电话', name: 'bazaDO.baza19', type: 'text', span: 6},

    {label: '入院途径', name: 'bazaDO.baza56', type: 'select', options: options.enterWay, span: 24},

    {label: '治疗类别', name: '治疗类别', type: 'select', options: options.treatmentType, span: 24},

    {label: '入院时间', name: 'bazaDO.baza24', type: 'date', span: 6},
    {label: '入院科别', name: 'bazaDO.hospitalization', type: 'text', span: 6},
    {label: '病房', name: 'bazaDO.hospitalizationwards', type: 'text', span: 6},
    {label: '转科科别', name: '转科科别', type: 'text', span: 6},

    {label: '出院时间', name: 'bazaDO.baza27', type: 'date', span: 6},
    {label: '出院科别', name: 'bazaDO.leavehospital', type: 'text', span: 6},
    {label: '病房', name: 'bazaDO.leavehospitalwards', type: 'text', span: 6},
    {label: '实际住院', name: 'bazaDO.baza29', type: 'text', after: '天', span: 6},

    {label: '门(急)诊诊断(中医诊断)', name: 'baf9DO.baf902name', type: 'text', span: 18},
    {label: '疾病编码', name: 'baf9DO.baf902', type: 'text', span: 6},

    {label: '门(急)诊诊断(西医诊断)', name: 'bazaDO.baza36name', type: 'text', span: 18},
    {label: '疾病编码', name: 'bazaDO.bazad9', type: 'text', span: 6},

    {label: '实施临床路径', name: 'bazaDO.bazag1', type: 'select', options: options.clinicalWay, span: 12},
    {label: '使用医疗机构中药制剂', name: 'bazaDO.baza70', type: 'select', options: options.whether, span: 12},

    {label: '使用中医诊疗设备', name: 'bazaDO.bazag2', type: 'select', options: options.whether, span: 8},
    {label: '使用中医诊疗技术', name: 'bazaDO.baza71', type: 'select', options: options.whether, span: 8},
    {label: '辨证施护', name: 'bazaDO.bazag3', type: 'select', options: options.whether, span: 8},


    // 第二段（46 - 68）

    {label: '损伤、中毒的外部原因', name: 'bazaDO.baza79', type: 'text', span: 18},
    {label: '疾病编码', name: 'baf4DO.baf405', type: 'text', span: 6},

    {label: '病理诊断', name: '病理诊断', type: 'text', span: 18},
    {label: '疾病编码', name: '疾病编码4', type: 'text', span: 6},

    {label: '', name: 'bilispace', type: 'text', span: 18},
    {label: '病理号', name: '病理号', type: 'text', span: 6},

    {label: '药物过敏', name: 'bazaDO.baza52', type: 'select', options: options.DrugAllergy,  span: 18},
    {label: '死亡患者尸检', name: 'bazaDO.bazace', type: 'select', options: options.whether, span: 6},

    {label: '血型', name: 'bazaDO.baza45', type: 'select', options: options.bloodType,  span: 12},
    {label: 'Rh', name: 'bazaDO.bazac5', type: 'select', options: options.Rh, span: 12},

    {label: '科主任', name: 'bazaDO.bazab1', type: 'text', span: 6},
    {label: '主任(副主任)医师', name: 'bazaDO.baza32', type: 'text', span: 6},
    {label: '主治医师', name: 'bazaDO.baza33', type: 'text', span: 6},
    {label: '住院医师', name: 'bazaDO.baza34', type: 'text', span: 6},

    {label: '责任护士', name: 'bazaDO.bazabf', type: 'text', span: 6},
    {label: '主进修医师', name: 'bazaDO.bazab2', type: 'text', span: 6},
    {label: '实习医师', name: 'bazaDO.bazab4', type: 'text', span: 6},
    {label: '编码员', name: 'bazaDO.baza59', type: 'text', span: 6},

    {label: '病案质量', name: 'bazaDO.baza51', type: 'select', options: options.quality, span: 6},
    {label: '质控医师', name: 'bazaDO.bazab5', type: 'text', span: 6},
    {label: '质控护士', name: 'bazaDO.baza69', type: 'text', span: 6},
    {label: '质控日期', name: 'bazaDO.bazab6', type: 'date', span: 6},

    // 第三段（68 - end）

    {label: '离院方式', name: 'bazaDO.bazaf8', type: 'select', options: options.outWay, span: 24},

    {label: '是否有出院31天内再住院计划', name: 'bazaDO.bazad5', type: 'select', options: options.whether, span: 24},

    {label: '颅脑损伤患者昏迷时间：入院前', name: 'bazaDO.bazad7-days', type: 'text', after: '天', span: 8},
    {label: '', name: 'bazaDO.bazad7-hours', type: 'text', after: '小时', span: 3},
    {label: '', name: 'bazaDO.bazad7-minutes', type: 'text', after: '分钟', span: 3},
    {label: '入院后', name: 'bazaDO.bazad8-days', type: 'text', after: '天', span: 4},
    {label: '', name: 'bazaDO.bazad8-hours', type: 'text', after: '小时', span: 3},
    {label: '', name: 'bazaDO.bazad8-minutes', type: 'text', after: '分钟', span: 3},

    {label: '住院费用（元）：总费用', name: 'baf6DO.baf601', type: 'text', span: 12},
    {label: '(  自付金额', name: 'baf6DO.baf602', type: 'text', after: '）', span: 12},

    {label: '1.综合医疗服务类：（1）一般医疗服务费', name: 'baf6DO.baf603', type: 'text', span: 9},
    {label: '（2）一般治疗操作费', name: 'baf6DO.baf604', type: 'text', span: 5},
    {label: '（3）护理费', name: 'baf6DO.baf605', type: 'text', span: 5},
    {label: '（4）其他费用', name: 'baf6DO.baf606', type: 'text', span: 5},

    {label: '2.诊断类：（5）病理诊断费', name: 'baf6DO.baf607', type: 'text', span: 9},
    {label: '（6）实验室诊断费', name: 'baf6DO.baf608', type: 'text', span: 5},
    {label: '（7）影像学诊断费', name: 'baf6DO.baf609', type: 'text', span: 5},
    {label: '（8）临床诊断项目费', name: 'baf6DO.baf610', type: 'text', span: 5},

    {label: '3.治疗类：（9）非手术治疗项目费', name: 'baf6DO.baf611', type: 'text', span: 12},
    {label: '（临床物理治疗费', name: 'baf6DO.baf612', type: 'text', after: '）', span: 8},

    {label: '（10）手术治疗费', name: 'baf6DO.baf613', type: 'text', span: 5, offset: 0},
    {label: '（麻醉费', name: 'baf6DO.baf614', type: 'text', span: 5},
    {label: '手术费', name: 'baf6DO.baf615', type: 'text', after: '）', span: 5},

    {label: '4.康复类：（11）康复费', name: 'baf6DO.baf616', type: 'text', span: 24, width: 180},

    {label: '5.中医类：（12）中医治疗费', name: 'baf6DO.baf617', type: 'text', span: 24, width: 150},

    {label: '6.西药类：（13）西药费', name: 'baf6DO.baf618', type: 'text', span: 12},
    {label: '（抗菌药物费用', name: 'baf6DO.baf619', type: 'text', after: '）', span: 12},

    {label: '7.中药类：（14）中成药费', name: 'baf6DO.baf620', type: 'text', span: 12},
    {label: '（15）中草药费', name: 'baf6DO.baf621', type: 'text', after: '）', span: 12},

    {label: '8.血液和血液制品类：（16）血费', name: 'baf6DO.baf622', type: 'text', span: 8},
    {label: '（17）白蛋白类制品费', name: 'baf6DO.baf623', type: 'text', span: 8},
    {label: '（18）球蛋白类制品费', name: 'baf6DO.baf624', type: 'text', span: 8},

    {label: '（19）凝血因子类制品费', name: 'baf6DO.baf625', type: 'text', span: 8, offset: 0},
    {label: '（20）细胞因子类制品费', name: 'baf6DO.baf626', type: 'text', span: 8},

    {label: '9.耗材类：（21）检查用一次性医用材料费', name: 'baf6DO.baf627', type: 'text', span: 9},
    {label: '（22）治疗用一次性医用材料费', name: 'baf6DO.baf628', type: 'text', span: 7},
    {label: '（23）手术用一次性医用材料费', name: 'baf6DO.baf629', type: 'text', span: 8},

    {label: '10.其他类: （24）其他费', name: 'baf6DO.baf630', type: 'text', span: 8},
];

<template>
    <div class="homepage clearfix">

        <top-filter @onSearch="handleSearch"></top-filter>

        <div class="main">

            <div class="left-side">
                <div>
                    <el-table :data="list.tableData" border v-loading="list.loading" @row-contextmenu="handleLeftRowClick">
                        <el-table-column type="selection"></el-table-column>
                        <el-table-column prop="baza00" label="病案号" width="120"></el-table-column>
                        <el-table-column prop="baza02" label="姓名"></el-table-column>
                        <el-table-column prop="kb" label="出院科别" width="120"></el-table-column>
                        <el-table-column prop="BAZA27" label="出院日期" width="100"></el-table-column>
                        <el-table-column prop="baza65" label="ICD10"></el-table-column>
                        <el-table-column prop="dmmc" label="诊断名称" width="180"></el-table-column>
                    </el-table>
                </div>
                <div class="left-paging">
                    <el-pagination
                            style="float: right"
                            small
                            layout="prev, pager, next"
                            :pager-count="5"
                            :total="list.pager.total"
                            :current-page.sync="list.pager.page"
                            :page-size="list.pager.rows"
                            @current-change="handlePageChange"
                    >
                    </el-pagination>
<!--                    <paging-toolbar :pager="list.pager" :small="true" :pager-count="5" @change="getList(list.filters, list.pager)"/>-->
                </div>
            </div>

            <div class="right-side" v-loading="rightLoading">

                <el-row :gutter="16">
                    <input-item
                            v-for="item in firstInputs"
                            v-if="item.showCondition ? judge[item.showCondition] : true"
                            :name="item.name"
                            :label="item.label"
                            :value="inputValues[item.name]"
                            :type="item.type"
                            :after="item.after"
                            :max="item.max"
                            :min="item.min"
                            :options="item.options"
                            :span="item.span"
                            @change="handleInputItemChange"
                    />
                </el-row>

                <table class="table">
                    <thead>
                        <tr>
                            <th>{{judge.isZhongYi ? '出院中医诊断' : '出院诊断'}}</th>
                            <th>疾病编码</th>
                            <th>入院病情</th>
                            <th>{{judge.isZhongYi ? '出院西医诊断' : '出院诊断'}}</th>
                            <th>疾病编码</th>
                            <th>入院病情</th>
                        </tr>
                    </thead>
                    <draggable element="tbody" v-model="diagnoseTable.diagnoseData">
                        <tr v-for="(item, index) in diagnoseTable.diagnoseData">
                            <td>{{item.type === 'main' ? '主要诊断' : '其他诊断'}}</td>
                            <td><input type="text" v-model="item.code1" @keyup.32="showCodeInputDialog($event, index, 1)"></td>
                            <td><input type="text" v-model="item.name1" @keyup.32="showCodeInputDialog($event, index, 2)"></td>
                            <td>{{item.type === 'main' ? '主要诊断' : '其他诊断'}}</td>
                            <td><input type="text" v-model="item.code2" @keyup.32="showCodeInputDialog($event, index, 4)"></td>
                            <td><input type="text" v-model="item.name2" @keyup.32="showCodeInputDialog($event, index, 5)"></td>
                        </tr>
                    </draggable>
                </table>

                <el-row :gutter="16">
                    <input-item
                            v-for="item in secondInputs"
                            v-if="item.showCondition ? judge[item.showCondition] : true"
                            :name="item.name"
                            :label="item.label"
                            :value="inputValues[item.name]"
                            :type="item.type"
                            :after="item.after"
                            :max="item.max"
                            :min="item.min"
                            :options="item.options"
                            :span="item.span"
                            @change="handleInputItemChange"
                    />
                </el-row>

                <table class="table">
                    <thead>
                        <tr>
                            <th rowspan="2">手术操作编码</th>
                            <th rowspan="2">手术操作日期</th>
                            <th rowspan="2">手术级别</th>
                            <th rowspan="2">手术操作名称</th>
                            <th colspan="3">手术操作医师</th>
                            <th rowspan="2">切口愈合等级</th>
                            <th rowspan="2">麻醉方式</th>
                            <th rowspan="2">麻醉医师</th>
                        </tr>
                        <tr>
                            <th>术者</th>
                            <th>Ⅰ助</th>
                            <th>Ⅱ助</th>
                        </tr>
                    </thead>
                    <draggable element="tbody" v-model="operationTable.data">
                        <tr v-for="(item, index) in operationTable.data">
                            <td><input type="text" v-model="item.baf405" @keyup.32="showCodeInputDialog($event, index, 1)"></td>
                            <td><input type="text" v-model="item.baf411" @keyup.32="showCodeInputDialog($event, index, 2)"></td>
                            <td><input type="text" v-model="item.baf404" @keyup.32="showCodeInputDialog($event, index, 1)"></td>
                            <td><input type="text" v-model="item.baf405name" @keyup.32="showCodeInputDialog($event, index, 2)"></td>
                            <td><input type="text" v-model="item.baf409" @keyup.32="showCodeInputDialog($event, index, 1)"></td>
                            <td><input type="text" v-model="item.baf414" @keyup.32="showCodeInputDialog($event, index, 2)"></td>
                            <td><input type="text" v-model="item.baf415" @keyup.32="showCodeInputDialog($event, index, 1)"></td>
                            <td><input type="text" v-model="item.baf413" @keyup.32="showCodeInputDialog($event, index, 2)"></td>
                            <td><input type="text" v-model="item.baf410" @keyup.32="showCodeInputDialog($event, index, 1)"></td>
                            <td><input type="text" v-model="item.baf416" @keyup.32="showCodeInputDialog($event, index, 2)"></td>
                        </tr>
                    </draggable>
                </table>

                <el-row :gutter="16">
                    <input-item
                            v-for="item in thirdInputs"
                            v-if="item.showCondition ? judge[item.showCondition] : true"
                            :name="item.name"
                            :label="item.label"
                            :value="inputValues[item.name]"
                            :type="item.type"
                            :after="item.after"
                            :max="item.max"
                            :min="item.min"
                            :options="item.options"
                            :span="item.span"
                            :offset="item.offset"
                            :width="item.width"
                            @change="handleInputItemChange"
                    />
                </el-row>

            </div>

        </div>

        <el-dialog title="代码录入窗口" :visible.sync="diagnoseTable.visible" width="600px" :close-on-click-modal="false">
            <el-form :model="diagnoseTable.form" :inline="true">
                <el-form-item label="拼音码" v-if="diagnoseTable.isPingYin">
                    <el-input placeholder="请输入拼音码" v-model="diagnoseTable.form.code" @change="seachCodeData"></el-input>
                </el-form-item>
                <el-form-item label="名称">
                    <el-input placeholder="请输入名称" v-model="diagnoseTable.form.name" @change="seachCodeData"></el-input>
                </el-form-item>
            </el-form>
            <el-table
                    border
                    highlight-current-row
                    row-key="code"
                    :data="diagnoseTable.codeData"
                    :current-row-key="diagnoseTable.currentRowKey"
                    @row-click="setCurrentRowKey"
            >
                <el-table-column prop="code" label="拼音码"></el-table-column>
                <el-table-column prop="name" label="名称"></el-table-column>
            </el-table>
            <span slot="footer" class="dialog-footer">
                <el-button @click="diagnoseTable.visible = false">取 消</el-button>
                <el-button type="primary" @click="handleCodeInput">确 定</el-button>
            </span>
        </el-dialog>

    </div>
</template>

<script src="./index.js"></script>

<style lang="less" scoped>
    @import "./index.less";
</style>

<template>
    <el-col :md="span" :sm="12" :offset="offset" class="input-item">
        <div class="input-label" v-if="label">{{label}}</div>
        <div class="input-content" :id="name">

            <el-input
                    v-if="type === 'text'"
                    :style="style"
                    class="input-text"
                    :name="name"
                    v-model="itemValue"
                    @keydown.native.13="handleEnter"
            ></el-input>

            <el-input-number
                    v-if="type === 'number'"
                    :style="style"
                    class="input-number"
                    :name="name"
                    :controls="false"
                    :max="max"
                    :min="min"
                    v-model="itemValue"
                    @keydown.native.13="handleEnter"
            />

            <el-select
                    v-if="type === 'select'"
                    :style="style"
                    :name="name"
                    class="input-select"
                    v-model="itemValue"
                    placeholder=""
                    @keydown.native.13="handleEnter"
            >
                <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                />
            </el-select>

            <el-date-picker
                    v-if="type === 'date'"
                    class="input-date"
                    value-format="yyyy-MM-dd"
                    :popper-class=" 'date-' + name "
                    :style="style"
                    :name="name"
                    v-model="itemValue"
                    type="date"
                    :editable="false"
                    :clearable="false"
                    @keydown.native.13="handleEnter"
            >
            </el-date-picker>
        </div>
        <div class="input-after" v-if="after">{{after}}</div>
    </el-col>
</template>

<script>
    import utils from "../utils";
    export default {
        name: 'input-item',
        props: ['span', 'offset', 'width', 'name', 'label', 'type', 'after', 'max', 'min',  'options', 'value'],
        data() {
            return {
                style: this.width !== undefined ? `width: ${this.width}px` : ''
            }
        },
        computed: {
            itemValue: {
                get() {
                    return this.value
                },
                set(val) {
                    this.handleChange(val)
                }
            }
        },
        methods: {

            // 向上触发change
            handleChange(val) {
                this.$emit('change', this.name, val);
            },

            // 触发enter键：下一个聚焦
            handleEnter(e) {
                utils.focusNext(this.name)
            },
        }
    }
</script>

<style lang="less" scoped>
    .input-item {
        overflow: hidden;
        display: flex;
        color: #909399;
        margin-bottom: 15px;
    }
    .input-label {
        padding-right: 5px;
    }
    .input-after {
        margin-left: 5px;
    }
    .input-content {
        flex: 1
    }
    .input-text {

    }
    .input-number {
        line-height: 18px;
    }
    .input-text, .input-number, .input-select, .input-date {
        width: 100%;
        /deep/ .el-input__inner {
            border: 0;
            height: 20px;
            border-bottom: 1px solid #ccc;
            padding-bottom: 2px;
            border-radius: 0;
            font-size: 16px;
            text-align: left;
            padding-right: 15px;
        }
        /deep/ .el-input__icon {
            line-height: 20px;
            display: none;
        }
    }
</style>

<template>
    <!-- 上边区域 -->
    <div class="topside">
        <el-form :model="form" :inline="true">
            <el-form-item label="执行年度">
                <el-date-picker
                        v-model="form.time"
                        type="year"
                        size="mini">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="科别">
                <el-select v-model="form.kebie" size="mini">
                    <el-option
                            v-for="item in options"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                    ></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-radio-group v-model="form.radius">
                    <el-radio label="1">未审核</el-radio>
                    <el-radio label="2">已审核</el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="出院起止日期 ">
                <span style="padding-right: 5px">从</span>
                <el-date-picker v-model="form.outTimeStart" type="date" size="mini"></el-date-picker>
                <span style="padding-right: 5px">到</span>
                <el-date-picker v-model="form.outTimeEnd" type="date" size="mini"></el-date-picker>
            </el-form-item>
            <el-form-item label="定位病案号">
                <el-input v-model="form.id" size="mini"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" size="mini" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
    import {formatDate} from '../../../utils/index';
    export default {
        data() {
            return {
                options: [
                    {
                        value: "选项1",
                        label: "儿科"
                    },
                    {
                        value: "选项2",
                        label: "肛肠科"
                    },
                    {
                        value: "选项3",
                        label: "老年病科(光谷)"
                    },
                    {
                        value: "选项4",
                        label: "针灸科"
                    },
                    {
                        value: "选项5",
                        label: "产科(光谷)"
                    }
                ],
                form: {}
            }
        },
        methods: {
            handleSearch() {
                const filters = {};
                // 去除空值
                Object.keys(this.form).forEach(key => {
                    if (this.form[key]) filters[key] = this.form[key]
                });
                // 格式化时间
                if (filters.time) filters.time = filters.time.getFullYear();
                if (filters.outTimeStart) {
                    filters.outTimeStart = formatDate(filters.outTimeStart, 'YYYY-MM-DD')
                }
                if (filters.outTimeEnd) {
                    filters.outTimeEnd = formatDate(filters.outTimeEnd, 'YYYY-MM-DD')
                }
                // 触发onSearch
                this.$emit('onSearch', filters)
            }
        }
    }
</script>

<style lang="less" scoped>
    .topside {
        overflow: hidden;
        border-radius: 6px;
        background-color: #eee;

        /deep/ .el-input--mini .el-input__inner {
            width: 140px !important;
        }

        .el-form {
            margin-left: 50px;
            .el-form-item {
                margin-bottom: 12px;
            }
        }

        .el-date-editor.el-input,
        .el-date-editor.el-input__inner {
            width: 150px;
        }
    }
</style>

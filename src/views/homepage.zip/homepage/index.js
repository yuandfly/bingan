import TopFilter from './components/topFilter';
import {SearchHomePage, QueryPatient, NewAddHomePage, EditHomepage} from "@/api";
import PagingToolbar from "../../components/toolbar/paging";
import InputItem from './components/input-item';
import draggable from "vuedraggable";
import inputConfig from "./config/inputConfig";
import utils from './utils';
let timeOut = undefined;
export default {
    components: {TopFilter, PagingToolbar, InputItem, draggable},
    data() {
        return {
            // 右侧内容的loading
            rightLoading: false,
            // 三段输入项配置
            firstInputs: inputConfig.slice(0, 46),
            secondInputs: inputConfig.slice(46, 68),
            thirdInputs: inputConfig.slice(68, inputConfig.length),
            // 所有输入项的值
            inputValues: utils.initInputsValues(),
            // 顶部筛选和左侧表格相关
            list: {
                filters: {},
                pager: {
                    total: 100, // 总条数
                    page: 1, // 当前页
                    rows: 10 // 每页显示多少条
                },
                loading: false,
                tableData: []
            },
            // 一些判断
            judge: {
                isZhongYi: false, // 是否中医
                showNewBaby: true, // 是否显示新生儿输入项
                bz: false, // bz，是否为成年人 D、M
            },

            // 诊断表格相关
            diagnoseTable: {
                diagnoseData: [
                    {type: 'main', code1: 1, name1: 11, code2: 4, name2: 44},
                    {type: 'qita', code1: 2, name1: 22, code2: 5, name2: 55},
                    {type: 'qita', code1: 3, name1: 33, code2: 6, name2: 66},
                    {}
                ], // 诊断表格数据
                currentInput: {rowIndex: 0, colIndex: 0}, // 当前在录入诊断表格中哪行数据
                visible: false,
                isPingYin: true, // 是否拼音
                form: {code: undefined, name: undefined},
                currentRowKey: undefined,
                codeData: []
            },
            // 手术表格相关
            operationTable: {
                data: [{}, {}]
            },
        }
    },

    created() {
        window.addEventListener('keydown', this.handleKeyDown)
    },

    mounted() {
        // 获取左侧列表
        this.handleSearch({})
    },

    destroyed() {
      window.removeEventListener('keydown', this.handleKeyDown)
    },

    methods: {

        /* -------------------------------- 左侧列表相关 ------------------------------------- */

        /**
         * 顶部筛选
         * @param filters: topFilters组件处理过的查询条件
         */
        handleSearch(filters) {
            this.list.filters = filters;
            this.list.pager = {...this.list.pager, page: 1};
            this.getList(filters, {page: 1, rows: this.list.pager.rows})
        },

        /**
         * 分页change
         * @param page
         */
        handlePageChange(page) {
            this.list.pager.page = page;
            this.getList(this.list.filters, this.list.pager)
        },

        /**
         * 获取左侧列表数据
         * @param filters 筛选条件
         * @param pager 分页条件
         */
        getList(filters, pager) {
            console.log(pager)
            this.list.loading = true;
            SearchHomePage({...filters, page: pager.page, limit: pager.rows}).then(res => {
                this.list.pager.total = res.data.total;
                this.list.tableData = res.data.content;
                this.list.loading = false
            }).catch(err => {
                this.list.loading = false;
                this.$message({type: 'info', message: '获取列表失败'});
            })
        },

        /* -------------------------------- 输入项相关 ------------------------------------- */

        /**
         * 左侧表格行右击事件处理：获取右侧病历数据，初始化一次所有输入和表格
         */
        handleLeftRowClick(row, col, event) {
            event.preventDefault();
            this.rightLoading = true;
            QueryPatient(row.baza00).then(res => {
                if (res && res.code === 0) {
                    const {data} = res;
                    // 整理一些判断点
                    this.judge = {isZhongYi: false, showNewBaby: true, bz: 'M'};
                    // 整理组合所有输入项的值
                    this.inputValues = utils.setInputValues(data);
                    // 整理组合诊断表格的数据
                    this.diagnoseTable = utils.setDiagnoseTable(data);
                    // 整理组合手术表格的数据
                    this.opetationTable = utils.setOperationTable(data);
                    // 使第一个输入项获取焦点
                    utils.focusNext(inputConfig[0].name, true);
                } else {
                    this.$message({type: 'error', message: '获取失败'});
                }
                this.rightLoading = false;
            }).catch((e) => {
                this.rightLoading = false;
                throw new Error(e);
                this.$message({type: 'error', message: '初始化错误'});
            })
        },

        /**
         * 所有input-item输入项值的变化监听，记录到inputValues中
         * @param name：key
         * @param value
         */
        handleInputItemChange(name, value) {
            this.inputValues[name] = value
        },


        /* -------------------------------- 代码录入相关 ------------------------------------- */

        /**
         * 显示代码录入弹窗
         * @param e
         * @param rowIndex
         * @param colIndex
         */
        showCodeInputDialog(e, rowIndex, colIndex) {
            e.preventDefault();
            e.stopPropagation();
            this.diagnoseTable.visible = true;
            // 要记录是那一行数据在打开录入框
            this.diagnoseTable.currentInput = {rowIndex, colIndex};
            // 如果没有数据，则获取一次
            !this.diagnoseTable.codeData.length && this.seachCodeData()
        },

        /**
         * 获取代码录入窗口的表格数据
         */
        seachCodeData() {
            clearTimeout(timeOut);
            timeOut = setTimeout(() => {
                const key = Math.random();
                this.diagnoseTable.currentRowKey = key;
                this.diagnoseTable.codeData = [{code: key, name: '快递费'}, {code: 'dd', name: '打开给你'}]
            }, 200)
        },

        /**
         * 设置代码录入窗口当前选中行的key
         * @param row： 行数据
         */
        setCurrentRowKey(row) {
            this.diagnoseTable.currentRowKey = row.code
        },

        /**
         * 代码录入窗口提交确认
         */
        handleCodeInput() {
            const {codeData, currentRowKey} = this.diagnoseTable;
            const index = codeData.findIndex(item => item.code === currentRowKey);
            if (index >= 0) {
                // TODO 处理选择
                this.diagnoseTable.visible = false
            }
        },

        /**
         * 处理代码录入的按键事件
         * @param e Event
         */
        handleKeyDown(e) {
            switch (e.keyCode) {
                case 13: // enter
                    // 已打开代码录入窗口，提交选择
                    if (this.diagnoseTable.visible) this.handleCodeInput();
                    break;
                case 38: // 上
                case 40: // 下
                    if (this.diagnoseTable.visible) { // 已打开代码录入窗口，上下选择
                        const {codeData, currentRowKey} = this.diagnoseTable;
                        // 当前选择的索引
                        const index = codeData.findIndex(item => item.code === currentRowKey);
                        // 下一个需要选中状态的行索引
                        let nextIndex = 0;
                        if (index >= 0) {
                            // 按上键，当前index为0时，需选中最后一项，否则取上一项
                            if (e.keyCode === 38) nextIndex = index === 0 ? (codeData.length - 1) : (index - 1);
                            // 按下键，当前index为最后时，需选中第一项，否则取下一项
                            else nextIndex = index === (codeData.length - 1) ? 0 : (index + 1)
                        }
                        // 设置当前选中行的key
                        this.diagnoseTable.currentRowKey = codeData[nextIndex] ? codeData[nextIndex].code : undefined
                    }
                    break;
                default:
                    break;
            }
        }
    }
}
